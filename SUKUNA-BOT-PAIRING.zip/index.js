const { Client, RemoteAuth, MessageMedia } = require('whatsapp-web.js');
const { MongoStore } = require('wwebjs-mongo');
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

const prefix = "$";
const ownerNumber = "2349065140163";
const MONGO_URI = "mongodb://127.0.0.1:27017/sukuna_session";

mongoose.connect(MONGO_URI).then(() => {
    console.log("Connected to MongoDB.");
});

const store = new MongoStore({ mongoose: mongoose });

const client = new Client({
    authStrategy: new RemoteAuth({
        store: store,
        backupSyncIntervalMs: 300000
    }),
    puppeteer: {
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    }
});

const commands = {};
const commandsPath = path.join(__dirname, 'commands');
fs.readdirSync(commandsPath).forEach(file => {
    const command = require(`./commands/${file}`);
    commands[command.name] = command;
});

client.on('pairing-code', (code) => {
    console.log("PAIRING CODE (link this in WhatsApp > Linked Devices):", code);
});

client.on('ready', () => {
    console.log('SUKUNA V1.0 is online and ready.');
});

client.on('message', async (msg) => {
    const chat = await msg.getChat();
    if (!msg.body.startsWith(prefix)) {
        if (chat.isGroup) return;
        return msg.reply("Hello! This is SUKUNA V1.0. Type $help to see what I can do.");
    }
    const args = msg.body.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();
    const command = commands[commandName];
    if (!command) return;
    try {
        await command.execute(client, msg, args);
    } catch (error) {
        console.error(error);
        msg.reply("An error occurred while executing that command.");
    }
});

client.on('message_revoke_everyone', async (after, before) => {
    if (before && before.hasMedia && before.isViewOnce) {
        const media = await before.downloadMedia();
        const fileName = `./downloads/viewonce_${Date.now()}.jpg`;
        fs.writeFileSync(fileName, media.data, 'base64');
        const chat = await before.getChat();
        chat.sendMessage("Recovered view-once media:");
        chat.sendMessage(MessageMedia.fromFilePath(fileName));
    }
});

client.initialize();