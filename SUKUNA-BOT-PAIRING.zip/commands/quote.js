module.exports = {
    name: "quote",
    description: "Send a random motivational quote.",
    execute: async (client, msg, args) => {
        const quotes = [
            "Believe you can and you're halfway there.",
            "You are stronger than you think.",
            "Success is not for the lazy."
        ];
        const quote = quotes[Math.floor(Math.random() * quotes.length)];
        msg.reply(quote);
    }
};