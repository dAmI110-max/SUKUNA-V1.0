module.exports = {
    name: "help",
    description: "List all available commands.",
    execute: async (client, msg, args) => {
        msg.reply("Available commands: $ping, $help, $quote, $meme, $weather, $translate, $reminder, $joke, $qr, $gptchat, ...");
    }
};