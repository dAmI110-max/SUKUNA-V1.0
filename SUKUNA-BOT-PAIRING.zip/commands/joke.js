module.exports = {
    name: "joke",
    description: "Tell a random joke.",
    execute: async (client, msg, args) => {
        const jokes = [
            "Why don’t scientists trust atoms? Because they make up everything!",
            "I told my computer I needed a break, and now it won’t stop sending me Kit-Kats.",
            "Why did the scarecrow win an award? Because he was outstanding in his field!"
        ];
        const joke = jokes[Math.floor(Math.random() * jokes.length)];
        msg.reply(joke);
    }
};