module.exports = {
    name: "ping",
    description: "Replies with pong.",
    execute: async (client, msg, args) => {
        msg.reply("pong!");
    }
};